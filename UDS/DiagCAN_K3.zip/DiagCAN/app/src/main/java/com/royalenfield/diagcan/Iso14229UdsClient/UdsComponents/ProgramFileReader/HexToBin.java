package com.royalenfield.diagcan.Iso14229UdsClient.UdsComponents.ProgramFileReader;

import android.content.Context;
import android.net.Uri;

import com.royalenfield.diagcan.Iso14229UdsClient.UdsComponents.CrcCalculator.crc32Calculator;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class HexToBin {

    String flashingFilePath = null;
    private static long baseAddress = 0;
    private static long totalLength = 0;
    private static long startAddress = Long.MAX_VALUE;
    private static boolean isFirstDataRecord = true;

    public FirmwareProgramFile convertHexToBinary(Context context, Uri firmwareImageFileURI) throws IOException {
        long baseAddress = 0;
        long totalLength = 0;
        long startAddress = -1;
        int totalChecksum = 0;
        long nextExpectedAddress = 0;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        try (InputStream inputStream = context.getContentResolver().openInputStream(firmwareImageFileURI);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
             OutputStream outputStream = createTempFile(context)) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith(":")) continue;

                int recordLength = Integer.parseInt(line.substring(1, 3), 16);
                long address = Integer.parseInt(line.substring(3, 7), 16) & 0xFFFF;
                int recordType = Integer.parseInt(line.substring(7, 9), 16);
                String dataStr = line.substring(9, 9 + (recordLength * 2));

                switch (recordType) {
                    case 0x00:
                        if (isFirstDataRecord) {
                            isFirstDataRecord = false;
                            startAddress = baseAddress + address;
                        }
                        byte[] dataBytes = hexStringToByteArray(dataStr);
                        byteArrayOutputStream.write(dataBytes);
                        // Calculate checksum
                        int checksum = 0;
                        for (int j = 0; j < 8; j += 2) {
                            checksum += charPairToByte(line.substring(j + 1, j + 3));
                            checksum &= 0xFF; // Simulate an 8-bit overflow
                        }

                        for (byte byteValue : dataBytes) {
                            checksum += (byteValue & 0xFF);
                            checksum &= 0xFF;
                            outputStream.write(byteValue);
                        }

                        checksum = (~checksum) & 0xFF;
                        checksum += 1;
                        checksum &= 0xFF;

                        // Compare checksum
                        int actualChecksum = charPairToByte(line.substring(line.length() - 2));
                        if (checksum != actualChecksum) {
                            throw new IOException("Checksum mismatch.");
                        } else {
                            totalChecksum = totalChecksum + checksum;
                        }

                        totalLength += recordLength;
                        break;
                    case 0x01:
                        baseAddress = 0;
                        break;
                    case 0x02:
                        baseAddress = Long.parseLong(dataStr, 16) << 4;
                        break;
                    case 0x04:
                        baseAddress = Long.parseLong(dataStr, 16) << 16;
                        break;
                }
            }
            byte[] crcInput = byteArrayOutputStream.toByteArray();
            int crcoutput = crc32Calculator.calculateCrc32(crcInput);

            isFirstDataRecord=true;
            return new FirmwareProgramFile(totalLength, startAddress, flashingFilePath, crcoutput);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private static int charPairToByte(String s) {
        if (s == null || s.length() < 2) {
            throw new IllegalArgumentException("Input string must contain at least two characters.");
        }
        int val = 0;
        for (int i = 0; i < 2; ++i) {
            char c = Character.toLowerCase(s.charAt(i));
            val <<= 4;
            if (c >= '0' && c <= '9') {
                val |= c - '0';
            } else if (c >= 'a' && c <= 'f') {
                val |= 10 + (c - 'a');
            } else {
                throw new IllegalArgumentException("Invalid hex character");
            }
        }
        return val;
    }

    private byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) charPairToByte(s.substring(i, i + 2));
        }
        return data;
    }

    private OutputStream createTempFile(Context context) throws IOException {
        String fileName = Long.toString(System.currentTimeMillis());
        File tempFile = File.createTempFile(fileName + "_temp_binary", ".bin", context.getCacheDir());
        flashingFilePath = tempFile.getAbsolutePath();
        System.out.println("Temporary Program file path: " + flashingFilePath);
        return new FileOutputStream(tempFile);
    }


}
