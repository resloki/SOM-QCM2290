package com.royalenfield.diagcan.iso15765TP.Transport;

public enum CANFrameType {
    SINGLE_FRAME, FIRST_FRAME, CONSECUTIVE_FRAME, FLOW_CONTROL,UNKNOWN,MULTI_FRAME
}
