package com.royalenfield.diagcan;

import android.content.Context;
import android.net.Uri;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;

import com.royalenfield.diagcan.Iso14229UdsClient.ApplicationService;


/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */


@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private ApplicationService applicationService;
    Context appContext;
    Uri xmlFileUri = null;

    @Before
    public void useAppContext() {
        // Context of the app under test.
        appContext = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("com.re.diagcan", appContext.getPackageName());
    }

    @Test
    public void TestApplicationServices() {
        String filePath = "file:///android_asset/UDS_TemplateApplcationREUDSFlowConfig.xml";
        xmlFileUri = Uri.parse(filePath);

        applicationService = new ApplicationService(null,appContext);
        applicationService.startApplicationService(xmlFileUri);
    }


}